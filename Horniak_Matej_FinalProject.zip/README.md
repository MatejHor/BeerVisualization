# BeerVisualization

## Heroku link
https://beer-visualization.herokuapp.com/

## Instruction to run
1. You must have a python installed, version <= 3.8
2. pip install -r requirements.txt
3. python main.py